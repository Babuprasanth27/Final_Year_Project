import streamlit as st

st.set_page_config(page_title="Cyber IDS", layout="wide")

st.markdown("""
<style>
body {
    background: radial-gradient(circle at top, #0a0f1f, #020617);
    color: #e5e7eb;
}

.hero {
    text-align:center;
    padding:60px 20px 30px 20px;
}

.hero h1 {
    font-size:58px;
    background: linear-gradient(90deg,#00f5ff,#00ff88);
    -webkit-background-clip:text;
    color:transparent;
    font-weight:800;
}

.hero h3 {
    color:#94a3b8;
    margin-top:10px;
}

.card-grid {
    display:grid;
    grid-template-columns:repeat(auto-fit,minmax(260px,1fr));
    gap:24px;
    margin-top:50px;
}

.card {
    background:rgba(255,255,255,0.05);
    border:1px solid rgba(255,255,255,0.08);
    border-radius:20px;
    padding:25px;
    backdrop-filter: blur(12px);
    box-shadow:0 0 30px rgba(0,255,170,0.08);
}

.card h4 {
    color:#00ffcc;
}

.cta {
    display:flex;
    justify-content:center;
    gap:20px;
    margin-top:60px;
}

button {
    background: linear-gradient(90deg,#00f5ff,#00ff88) !important;
    color:#020617 !important;
    border:none !important;
    padding:16px 40px !important;
    border-radius:50px !important;
    font-weight:700 !important;
    font-size:18px !important;
}
</style>
""", unsafe_allow_html=True)


st.markdown("""
<div class="hero">
    <h1>🛡 CYBER IDS</h1>
    <h3>Hybrid Machine Learning & Deep Learning Intrusion Detection System</h3>
</div>
""", unsafe_allow_html=True)


st.markdown("""
<div class="card-grid">
    <div class="card"><h4>⚡ Real-Time Detection</h4><p>Instant identification of cyber attacks on live network traffic.</p></div>
    <div class="card"><h4>🧠 Hybrid AI Engine</h4><p>Combines Random Forest, SVM, XGBoost & ANN models.</p></div>
    <div class="card"><h4>🚨 Severity Classification</h4><p>Automatic grading of attacks into MEDIUM, HIGH & CRITICAL.</p></div>
    <div class="card"><h4>📊 SOC Dashboard</h4><p>Professional cyber security monitoring interface.</p></div>
    <div class="card"><h4>🛡 Auto Defense</h4><p>Automatic blocking of malicious IPs (future upgrade).</p></div>
    <div class="card"><h4>📑 Compliance Logs</h4><p>Secure SQLite based attack logging system.</p></div>
</div>
""", unsafe_allow_html=True)


st.markdown('<div class="cta">', unsafe_allow_html=True)
col1,col2 = st.columns(2)

with col1:
    if st.button("LOGIN"):
        st.switch_page("pages/login.py")

with col2:
    if st.button("SIGN UP"):
        st.switch_page("pages/signup.py")

st.markdown('</div>', unsafe_allow_html=True)
