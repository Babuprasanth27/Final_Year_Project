import streamlit as st
from auth import login

st.title("Login")

u = st.text_input("Username")
p = st.text_input("Password", type="password")

if st.button("Login"):
    if login(u,p):
        st.session_state.user = u
        st.success("Login successful")
        st.switch_page("pages/Dashboard.py")
    else:
        st.error("Invalid credentials")
