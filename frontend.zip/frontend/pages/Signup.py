import streamlit as st
from auth import signup

st.title("Signup")

u = st.text_input("Username")
p = st.text_input("Password", type="password")

if st.button("Signup"):
    if signup(u,p):
        st.success("Account created")
        st.switch_page("pages/Dashboard.py")
    else:
        st.error("Username exists")
