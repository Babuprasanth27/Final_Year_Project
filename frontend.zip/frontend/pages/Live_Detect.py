import streamlit as st
import requests
import pandas as pd
from db import init_db, get_db
from logger import log_attack
from utils import get_severity

API_URL = "http://127.0.0.1:8000/predict/live"

st.set_page_config("Live Network IDS", "🌐", layout="wide")
init_db()

st.title("🌐 Live Network Intrusion Detection")

st.info("Captures real network traffic and detects cyber attacks in real time.")

duration = st.slider("Capture Duration (seconds)", 2, 30, 5)

if st.button("Start Live Detection"):
    resp = requests.get(f"{API_URL}?duration={duration}")

    if resp.status_code != 200:
        st.error("Live API error")
        st.text(resp.text)
        st.stop()

    try:
        res = resp.json()
    except:
        st.error("Invalid backend response")
        st.text(resp.text)
        st.stop()

    st.subheader("📡 Live Detection Result")
    st.json(res)

    # Use meta for severity logic
    meta = res.get("meta", {})
    features = {
        "flow_packets_per_seconds": meta.get("pps", 0),
        "flow_bytes_per_seconds": meta.get("bps", 0)
    }

    severity, reason = get_severity(res["prediction"], features)
    log_attack("LIVE", "NETWORK", res["prediction"], severity, reason)


# ==========================
# Logs Table
# ==========================
st.subheader("📊 Detection Logs")
conn = get_db()
df = pd.read_sql("SELECT * FROM logs ORDER BY id DESC LIMIT 100", conn)

def color_severity(val):
    if val == "CRITICAL":
        return "background-color:#ff4d4d"
    if val == "HIGH":
        return "background-color:#ff944d"
    if val == "MEDIUM":
        return "background-color:#ffd11a"
    return "background-color:#a6ff4d"

st.dataframe(df.style.applymap(color_severity, subset=["severity"]), use_container_width=True)
