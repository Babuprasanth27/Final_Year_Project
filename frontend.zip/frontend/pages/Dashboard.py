import streamlit as st

if "user" not in st.session_state:
    st.switch_page("pages/Login.py")

st.title("Welcome " + st.session_state.user)

if st.button("Manual Detection"):
    st.switch_page("pages/Manual_Detect.py")

if st.button("Live Detection"):
    st.switch_page("pages/Live_Detect.py")

if st.button("Logout"):
    del st.session_state.user
    st.switch_page("pages/Home.py")
