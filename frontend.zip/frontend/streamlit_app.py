import streamlit as st
import requests
import pandas as pd
from db import init_db, get_db
from logger import log_attack
from utils import get_severity

API_URL = "http://127.0.0.1:8000/predict/manual"

st.set_page_config("Network IDS Dashboard", "🚨", layout="wide")
init_db()

st.title("🚨 Network Intrusion Detection System")

# ==========================
# Manual Detection Panel
# ==========================
# st.sidebar.header("Manual Traffic Input")

# src_ip = st.sidebar.text_input("Source IP", "192.168.1.10")
# dst_ip = st.sidebar.text_input("Destination IP", "192.168.1.1")

# protocol = st.sidebar.number_input("Protocol", 0, 255, 17)
# flow_duration = st.sidebar.number_input("Flow Duration (sec)", 0.0)
# fwd = st.sidebar.number_input("Forward Packets", 0)
# bwd = st.sidebar.number_input("Backward Packets", 0)
# fwd_len = st.sidebar.number_input("Forward Bytes", 0.0)
# bwd_len = st.sidebar.number_input("Backward Bytes", 0.0)
# fwd_mean = st.sidebar.number_input("Forward Mean Bytes", 0.0)
# bwd_mean = st.sidebar.number_input("Backward Mean Bytes", 0.0)
# fwd_pps = st.sidebar.number_input("Forward PPS", 0.0)
# bwd_pps = st.sidebar.number_input("Backward PPS", 0.0)
# fwd_iat = st.sidebar.number_input("Forward IAT Mean", 0.0)
# bwd_iat = st.sidebar.number_input("Backward IAT Mean", 0.0)
# flow_iat = st.sidebar.number_input("Flow IAT Mean", 0.0)
# flow_pps = st.sidebar.number_input("Flow PPS", 0.0)
# flow_bps = st.sidebar.number_input("Flow BPS", 0.0)

# if st.sidebar.button("Run Detection"):
#     payload = {
#         "src_ip": src_ip,
#         "dst_ip": dst_ip,
#         "protocol": protocol,
#         "flow_duration": flow_duration,
#         "total_forward_packets": fwd,
#         "total_backward_packets": bwd,
#         "total_forward_packets_length": fwd_len,
#         "total_backward_packets_length": bwd_len,
#         "forward_packet_length_mean": fwd_mean,
#         "backward_packet_length_mean": bwd_mean,
#         "forward_packets_per_second": fwd_pps,
#         "backward_packets_per_second": bwd_pps,
#         "forward_iat_mean": fwd_iat,
#         "backward_iat_mean": bwd_iat,
#         "flow_iat_mean": flow_iat,
#         "flow_packets_per_seconds": flow_pps,
#         "flow_bytes_per_seconds": flow_bps
#     }

#     resp = requests.post(API_URL, json=payload)

#     if resp.status_code != 200:
#         st.error("Backend API error")
#         st.text(resp.text)
#         st.stop()

#     try:
#         res = resp.json()
#     except:
#         st.error("Backend returned invalid response")
#         st.text(resp.text)
#         st.stop()

#     st.subheader("🔍 Prediction Result")
#     st.json(res)

#     severity, reason = get_severity(res["prediction"], payload)

#     log_attack(src_ip, dst_ip, res["prediction"], severity, reason)


# ==========================
# Logs Table
# ==========================
# st.subheader("📊 Detection Logs")
# conn = get_db()
# df = pd.read_sql("SELECT * FROM logs ORDER BY id DESC LIMIT 100", conn)

# def color_severity(val):
#     if val == "CRITICAL":
#         return "background-color:#ff4d4d"
#     if val == "HIGH":
#         return "background-color:#ff944d"
#     if val == "MEDIUM":
#         return "background-color:#ffd11a"
#     return "background-color:#a6ff4d"

# st.dataframe(df.style.applymap(color_severity, subset=["severity"]), use_container_width=True)
